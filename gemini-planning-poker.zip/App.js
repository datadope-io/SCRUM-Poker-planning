// window.App
window.App = () => {
  const { useState, useEffect, useCallback } = window.React;
  const { UserType, GamePhase, FIBONACCI_DECK } = window;
  const { AI_PERSONAS } = window;
  const { generateAiVote } = window;
  const { Card, PlayerAvatar, StoryPanel, ResultsChart } = window;
  const { Users, Bot, Wifi, PlayCircle, Plus, Share2, Check } = window.Lucide;

  // --- State ---
  const [currentUser] = useState({
    id: 'user-1',
    name: 'You',
    type: UserType.HUMAN,
    avatarUrl: 'https://picsum.photos/100/100?random=100'
  });

  const [roomId, setRoomId] = useState('');
  const [players, setPlayers] = useState([currentUser]);
  const [story, setStory] = useState({ title: '', description: '' });
  const [phase, setPhase] = useState(GamePhase.SETUP);
  const [votes, setVotes] = useState({});
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [copied, setCopied] = useState(false);

  // --- Room Management ---
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const rid = params.get('room');
    if (rid) {
      setRoomId(rid);
    } else {
      const newId = Math.random().toString(36).substring(2, 9);
      setRoomId(newId);
      window.history.replaceState(null, '', `?room=${newId}`);
    }
  }, []);

  const createNewGame = () => {
    if (phase !== GamePhase.SETUP && !window.confirm("Start a new game? Current progress will be lost.")) {
      return;
    }
    const newId = Math.random().toString(36).substring(2, 9);
    setRoomId(newId);
    window.history.pushState(null, '', `?room=${newId}`);
    
    // Reset State
    setStory({ title: '', description: '' });
    setVotes({});
    setPhase(GamePhase.SETUP);
    setPlayers([currentUser]);
  };

  const copyInviteLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  // --- Helpers ---

  // Add AI Players
  const addAiPlayers = () => {
    const shuffled = [...AI_PERSONAS].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 3);
    const newAiPlayers = selected.map(p => ({
      id: p.id,
      name: p.name,
      type: UserType.AI,
      avatarUrl: `https://picsum.photos/100/100?random=${p.avatarSeed}`,
      persona: p.description
    }));
    
    const existingIds = new Set(players.map(p => p.id));
    const toAdd = newAiPlayers.filter(p => !existingIds.has(p.id));
    
    setPlayers([...players, ...toAdd]);
  };

  const simulateRemotePlayer = () => {
      const id = `remote-${Date.now()}`;
      const newPlayer = {
          id,
          name: `Remote Dev ${players.filter(p => p.type === UserType.HUMAN).length + 1}`,
          type: UserType.HUMAN,
          avatarUrl: `https://picsum.photos/100/100?random=${id}`
      };
      setPlayers(prev => [...prev, newPlayer]);
  };

  const handleVote = (value) => {
    if (phase !== GamePhase.VOTING) return;
    
    setVotes(prev => ({
      ...prev,
      [currentUser.id]: { playerId: currentUser.id, value }
    }));
  };

  const triggerAiVotes = useCallback(async () => {
    if (phase !== GamePhase.VOTING) return;
    
    const aiPlayers = players.filter(p => p.type === UserType.AI);
    if (aiPlayers.length === 0) return;

    setIsProcessingAI(true);
    
    const aiVotePromises = aiPlayers.map(async (player) => {
        await new Promise(r => setTimeout(r, 1000 + Math.random() * 3000));
        
        const aiPersona = AI_PERSONAS.find(p => p.id === player.id);
        if (!aiPersona) return null;

        const result = await generateAiVote(story, aiPersona.name, aiPersona.role);
        
        return {
            playerId: player.id,
            value: result.points,
            reasoning: result.reasoning
        };
    });

    const results = await Promise.all(aiVotePromises);
    
    setVotes(prev => {
        const newVotes = { ...prev };
        results.forEach(r => {
            if(r) newVotes[r.playerId] = r;
        });
        return newVotes;
    });

    setIsProcessingAI(false);
  }, [phase, players, story]);

  useEffect(() => {
     if (phase === GamePhase.VOTING) {
         const remotePlayers = players.filter(p => p.type === UserType.HUMAN && p.id !== currentUser.id);
         remotePlayers.forEach(p => {
             if (votes[p.id]) return;

             const delay = 2000 + Math.random() * 4000;
             const timeout = setTimeout(() => {
                 const randomCard = FIBONACCI_DECK[Math.floor(Math.random() * (FIBONACCI_DECK.length - 1))];
                 setVotes(prev => ({
                     ...prev,
                     [p.id]: { playerId: p.id, value: randomCard }
                 }));
             }, delay);
             return () => clearTimeout(timeout);
         });
     }
  }, [phase, players, currentUser.id, votes]);

  useEffect(() => {
    if (phase === GamePhase.VOTING) {
        if (players.some(p => p.type === UserType.AI) && !isProcessingAI) {
             const aiIds = players.filter(p => p.type === UserType.AI).map(p => p.id);
             const hasAiVoted = aiIds.every(id => votes[id]);
             if (!hasAiVoted) {
                 triggerAiVotes();
             }
        }
    }
  }, [phase, players, triggerAiVotes, votes, isProcessingAI]);

  const startVoting = () => {
    setVotes({});
    setPhase(GamePhase.VOTING);
  };

  const revealVotes = () => {
    setPhase(GamePhase.REVEALED);
  };

  const restartRound = () => {
    setVotes({});
    setPhase(GamePhase.VOTING);
  };

  const resetGame = () => {
    setStory({ title: '', description: '' });
    setVotes({});
    setPhase(GamePhase.SETUP);
  };

  const allVoted = players.length > 0 && players.every(p => !!votes[p.id]);

  return (
    <div className="min-h-screen bg-poker-bg text-white pb-20">
      <header className="bg-slate-900 border-b border-slate-800 px-4 md:px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3 w-full md:w-auto">
           <div className="bg-indigo-600 p-2 rounded-lg">
             <Users size={24} className="text-white" />
           </div>
           <div className="flex flex-col">
              <h1 className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent leading-none">
                Gemini Planning Poker
              </h1>
              <span className="text-xs text-slate-500 font-mono mt-1">Room: {roomId}</span>
           </div>
        </div>
        
        <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3 w-full md:w-auto">
            <div className="flex items-center gap-2 mr-2">
              <button 
                onClick={copyInviteLink}
                className={`flex items-center gap-2 px-3 py-1.5 rounded text-sm transition-all border ${
                    copied 
                    ? 'bg-emerald-900/30 border-emerald-500/50 text-emerald-400' 
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-300'
                }`}
                title="Copy Link to Clipboard"
              >
                {copied ? <Check size={16} /> : <Share2 size={16} />}
                <span className="hidden sm:inline">{copied ? 'Copied!' : 'Share'}</span>
              </button>

              <button 
                onClick={createNewGame}
                className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-sm transition-all shadow-lg hover:shadow-indigo-500/25 border border-indigo-400"
              >
                <Plus size={16} />
                <span className="hidden sm:inline">New Game</span>
              </button>
            </div>

            <div className="h-6 w-px bg-slate-700 hidden md:block mx-1"></div>

            <button 
              onClick={addAiPlayers}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-sm transition-all"
              title="Add AI Teammates"
            >
               <Bot size={16} className="text-indigo-400" />
               <span className="hidden lg:inline">Add AI</span>
            </button>
            <button 
              onClick={simulateRemotePlayer}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-sm transition-all"
              title="Simulate Remote User Joining"
            >
               <Wifi size={16} className="text-emerald-400" />
               <span className="hidden lg:inline">Simulate User</span>
            </button>
        </div>
      </header>

      <main className="container mx-auto px-4 pt-8">
        
        <StoryPanel 
          story={story} 
          phase={phase} 
          onUpdateStory={setStory}
          onStartVoting={startVoting}
          onReset={resetGame}
          onRevote={restartRound}
          canEdit={phase === GamePhase.SETUP}
        />

        {phase !== GamePhase.SETUP && (
            <>
                <div className="relative min-h-[300px] mb-12 flex justify-center">
                    <div className="flex flex-wrap justify-center gap-8 md:gap-16 items-center w-full max-w-5xl">
                        {players.map(player => (
                            <PlayerAvatar 
                                key={player.id} 
                                player={player} 
                                vote={votes[player.id]}
                                phase={phase}
                            />
                        ))}
                    </div>

                    {phase === GamePhase.VOTING && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                            <button
                                onClick={revealVotes}
                                disabled={!allVoted}
                                className={`
                                    flex items-center gap-2 px-8 py-4 rounded-full font-bold text-lg shadow-2xl transition-all transform
                                    ${allVoted 
                                        ? 'bg-indigo-600 hover:bg-indigo-500 hover:scale-110 text-white animate-bounce-subtle' 
                                        : 'bg-slate-700 text-slate-400 cursor-not-allowed opacity-80'
                                    }
                                `}
                            >
                                <PlayCircle size={24} />
                                {allVoted ? 'Reveal Cards' : 'Waiting...'}
                            </button>
                        </div>
                    )}
                </div>

                {phase === GamePhase.REVEALED && (
                    <div className="mb-12 animate-flip-in">
                        <ResultsChart votes={votes} />
                    </div>
                )}
            </>
        )}

        <div className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-sm border-t border-slate-800 p-4 transition-transform duration-300 z-40 shadow-2xl">
            <div className="max-w-4xl mx-auto flex gap-2 sm:gap-4 overflow-x-auto justify-start sm:justify-center pb-2 px-2 snap-x">
                {FIBONACCI_DECK.map(value => (
                    <div key={value} className="snap-center shrink-0">
                        <Card 
                            value={value} 
                            isSmall={true}
                            selected={votes[currentUser.id]?.value === value}
                            onClick={() => handleVote(value)}
                            disabled={phase !== GamePhase.VOTING}
                        />
                    </div>
                ))}
            </div>
            {phase === GamePhase.VOTING && !votes[currentUser.id] && (
                <p className="text-center text-indigo-400 text-xs mt-2 animate-pulse font-medium">
                    Select a card to cast your vote
                </p>
            )}
        </div>

      </main>
    </div>
  );
};