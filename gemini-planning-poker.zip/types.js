// Enums must be objects in global scope
window.UserType = {
  HUMAN: 'HUMAN',
  AI: 'AI'
};

window.GamePhase = {
  SETUP: 'SETUP',
  VOTING: 'VOTING',
  REVEALED: 'REVEALED'
};

window.FIBONACCI_DECK = [1, 2, 3, 5, 8, 13, 21, '?'];